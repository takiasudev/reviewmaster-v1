#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
import json
import os
from functools import lru_cache
from typing import Dict, Optional
from datetime import datetime, timezone
import logging

# 標準PyJWTライブラリをインポート（競合回避）
import sys
import importlib.util

jwt_spec = importlib.util.find_spec("PyJWT")
if jwt_spec:
    import PyJWT as jwt_lib

    jwt = jwt_lib
else:
    # フォールバック: 直接PyJWTをインポート
    import jwt

# ロガーセットアップ
logger = logging.getLogger(__name__)


class JWTValidator:
    """JWT検証ユーティリティクラス

    ライセンスサーバーから発行されたJWTトークンの検証を行う
    セキュリティ向上のため、AWS情報はランタイムで取得
    """

    def __init__(self):
        # DynamoDB設定（共有リソース使用）
        from utils.shared_resources import get_shared_manage_table

        self.table = get_shared_manage_table()

        # AWS Context は LicenseValidator から取得（重複削除）

        # 公開鍵キャッシュ
        self._cached_public_keys = None

    def _get_aws_context(self) -> Dict[str, str]:
        """AWS実行コンテキストを取得（LicenseValidator から共有取得）"""
        try:
            # LicenseValidator のグローバルインスタンスから取得（重複削除）
            from utils.license_validator import license_validator

            return license_validator.get_aws_context()
        except Exception as e:
            logger.error(f"AWS context取得エラー: {str(e)}")
            raise

    def get_public_keys(self) -> Dict:
        """公開鍵取得（LicenseValidatorから共有取得）

        Returns:
            Dict: 公開鍵情報

        Raises:
            Exception: 公開鍵取得に失敗した場合
        """
        try:
            # LicenseValidatorから公開鍵を取得（重複削除）
            from utils.license_validator import license_validator

            public_keys = license_validator.get_public_keys_shared()

            if public_keys:
                logger.debug("[jwt_validator] LicenseValidatorから公開鍵取得成功")
                return public_keys
            else:
                logger.error("[jwt_validator] LicenseValidatorから公開鍵取得失敗")
                raise ValueError("公開鍵が見つかりません")

        except Exception as e:
            logger.error(f"[jwt_validator] 公開鍵取得エラー: {str(e)}")
            raise

    def validate_jwt(self, token: str) -> Optional[Dict]:
        """JWT検証

        Args:
            token (str): 検証対象のJWTトークン

        Returns:
            Optional[Dict]: 検証成功時はペイロード、失敗時はNone
        """
        try:
            # ヘッダーからkidを取得
            header = jwt.get_unverified_header(token)
            kid = header.get("kid")

            if not kid:
                logger.error("JWT headerにkidが見つかりません")
                return None

            # 公開鍵取得
            public_keys = self.get_public_keys()
            public_key = self._find_public_key(public_keys, kid)

            if not public_key:
                logger.error(f"公開鍵が見つかりません: kid={kid}")
                return None

            # JWT検証
            payload = jwt.decode(
                token,
                public_key,
                algorithms=["RS256"],
                audience="reviewmaster-app",
                issuer="reviewmaster-license-server",
            )

            # 環境照合（偽造防止）
            token_account_id = payload.get("aws-account-id")
            aws_context = self._get_aws_context()
            current_account_id = aws_context["aws_account_id"]

            if token_account_id != current_account_id:
                logger.error(
                    f"AWS account ID不一致: Token={token_account_id}, Current={current_account_id}"
                )
                return None

            # CloudFront Distribution ID照合（追加セキュリティ）
            token_cf_ids = payload.get("cf-distribution-ids", [])
            logger.debug(f"CloudFront Distribution ID確認: {token_cf_ids}")

            logger.debug(
                f"JWT検証成功: plan={payload.get('plan')}, sub={payload.get('sub')}"
            )
            return payload

        except jwt.ExpiredSignatureError:
            logger.warning("JWT有効期限切れ")
            return None
        except jwt.InvalidTokenError as e:
            logger.error(f"JWT無効: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"JWT検証エラー: {str(e)}")
            return None

    def validate_jwt_with_grace_period(self, token: str) -> Optional[Dict]:
        """JWT検証（猶予期間考慮）

        期限切れのJWTでも猶予期間内であれば有効とする

        Args:
            token (str): 検証対象のJWTトークン

        Returns:
            Optional[Dict]: 検証成功時はペイロード（ステータス情報付き）、失敗時はNone
        """
        try:
            # 基本的なJWT検証（期限切れは無視）
            header = jwt.get_unverified_header(token)
            kid = header.get("kid")

            if not kid:
                logger.error("JWT headerにkidが見つかりません")
                return None

            public_keys = self.get_public_keys()
            public_key = self._find_public_key(public_keys, kid)

            if not public_key:
                logger.error(f"公開鍵が見つかりません: kid={kid}")
                return None

            # 期限切れを無視してペイロードを取得
            try:
                payload = jwt.decode(
                    token,
                    public_key,
                    algorithms=["RS256"],
                    audience="reviewmaster-app",
                    issuer="reviewmaster-license-server",
                    options={"verify_exp": False},  # 期限切れチェックを無効化
                )
            except jwt.InvalidTokenError as e:
                logger.error(f"JWT無効: {str(e)}")
                return None

            # 環境照合
            token_account_id = payload.get("aws-account-id")
            aws_context = self._get_aws_context()
            current_account_id = aws_context["aws_account_id"]

            if token_account_id != current_account_id:
                logger.error(
                    f"AWS account ID不一致: Token={token_account_id}, Current={current_account_id}"
                )
                return None

            # ライセンス管理サーバのstatusフィールドを最優先で確認
            jwt_status = payload.get("status")

            if jwt_status == "canceled":
                # canceledライセンスは時間に関係なくcanceledステータスを維持
                payload["license-status"] = "canceled"
                logger.debug(f"canceledライセンス検出: status={jwt_status}")
            else:
                # その他のステータスは時間ベースで判定
                current_time = datetime.now(timezone.utc).timestamp()
                expiry = payload.get("exp", 0)
                warning_threshold = expiry - (7 * 24 * 60 * 60)  # 7日前
                grace_period_end = expiry + (3 * 24 * 60 * 60)  # 期限から3日後

                if current_time < warning_threshold:
                    # 通常期間
                    payload["license-status"] = "active"
                elif current_time < expiry:
                    # 警告期間（期限7日前〜期限当日）
                    payload["license-status"] = "warning"
                    days_remaining = int((expiry - current_time) / (24 * 60 * 60))
                    payload["grace-period-message"] = (
                        f"ライセンスの期限まで{days_remaining}日です"
                    )
                elif current_time < grace_period_end:
                    # 猶予期間（期限切れ〜3日後）
                    payload["license-status"] = "grace-period"
                    days_remaining = int(
                        (grace_period_end - current_time) / (24 * 60 * 60)
                    )
                    payload["grace-period-message"] = (
                        f"ライセンスが期限切れです。{days_remaining}日後に無料版制限になります"
                    )
                else:
                    # 猶予期間終了
                    logger.info("猶予期間終了：無料版制限に移行")
                    return None

            logger.debug(
                f"JWT検証成功（猶予期間対応）: status={payload['license-status']}, plan={payload.get('plan')}"
            )
            return payload

        except Exception as e:
            logger.error(f"JWT検証エラー（猶予期間対応）: {str(e)}")
            return None

    def _find_public_key(self, public_keys: Dict, kid: str) -> Optional[str]:
        """公開鍵検索

        Args:
            public_keys (Dict): 公開鍵データ
            kid (str): Key ID

        Returns:
            Optional[str]: 見つかった公開鍵、見つからない場合はNone
        """
        try:
            keys = public_keys.get("keys", [])
            for key in keys:
                if key.get("kid") == kid:
                    # PEM形式の公開鍵を返す
                    pem_key = key.get("pem")
                    if pem_key:
                        logger.debug(f"公開鍵発見: kid={kid}")
                        return pem_key
                    else:
                        logger.error(f"PEM形式の公開鍵が見つかりません: kid={kid}")
                        return None

            logger.error(f"指定されたkidの公開鍵が見つかりません: kid={kid}")
            return None

        except Exception as e:
            logger.error(f"公開鍵検索エラー: {str(e)}")
            return None

    def get_aws_context(self) -> Dict[str, str]:
        """AWS実行コンテキストを取得

        Returns:
            Dict[str, str]: AWS Account IDとRegion
        """
        return self._get_aws_context()
