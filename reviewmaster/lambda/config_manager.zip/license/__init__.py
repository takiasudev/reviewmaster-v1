#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
ReviewMaster License Management Module

ライセンス管理機能を提供するモジュール
- JWT検証
- ライセンスサーバー連携
- ライセンス状態管理
"""

__version__ = "1.0.0"
__author__ = "ReviewMaster Development Team"

# ライセンス管理関連のクラスとユーティリティ
from .license_service import LicenseService
from .jwt_validator import JWTValidator

__all__ = [
    'LicenseService',
    'JWTValidator'
]
