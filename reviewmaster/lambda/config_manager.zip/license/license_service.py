#!/usr/bin/env python
# -*- coding: utf-8 -*-

import boto3
import json
import requests
import os
import time
from typing import Dict, Optional, List
from datetime import datetime, timezone, timedelta
import logging

# ロガーセットアップ
logger = logging.getLogger(__name__)


class LicenseService:
    """ライセンス業務ロジッククラス

    ライセンスサーバーとの連携、DynamoDBとの連携、
    ライセンス状態管理を行う
    """

    def __init__(self):
        self.license_server_url = os.environ.get("LICENSE_SERVER_API_URL")
        # DynamoDB設定（共有リソース使用）
        from utils.shared_resources import get_shared_manage_table

        self.manage_table = get_shared_manage_table()

        # AWS Context は LicenseValidator から取得（重複削除）

    def _get_aws_context(self) -> Dict[str, str]:
        """AWS実行コンテキストを取得（LicenseValidator から共有取得）"""
        try:
            # LicenseValidator のグローバルインスタンスから取得（重複削除）
            from utils.license_validator import license_validator

            return license_validator.get_aws_context()
        except Exception as e:
            logger.error(f"AWS context取得エラー: {str(e)}")
            raise

    def _get_cloudfront_distribution_ids(self) -> List[str]:
        """環境変数ALLOWED_ORIGINSからCloudFrontDistributionIDを取得"""
        try:
            allowed_origins = os.environ.get("ALLOWED_ORIGINS", "")
            if not allowed_origins or allowed_origins == "*":
                logger.warning(
                    "ALLOWED_ORIGINS環境変数が設定されていないか、ワイルドカードです"
                )
                return []

            distribution_ids = []

            # ALLOWED_ORIGINSからCloudFrontのURLを抽出
            # 例: "https://d1234567890123.cloudfront.net" -> "d1234567890123"
            if ".cloudfront.net" in allowed_origins:
                import re

                match = re.search(r"([a-zA-Z0-9]+)\.cloudfront\.net", allowed_origins)
                if match:
                    distribution_id = match.group(1)
                    distribution_ids.append(distribution_id)
                    logger.debug(
                        f"CloudFrontDistributionID取得成功: {distribution_id} (from ALLOWED_ORIGINS)"
                    )
                else:
                    logger.warning(
                        f"CloudFrontのDistribution IDを抽出できませんでした: {allowed_origins}"
                    )
            else:
                logger.warning(
                    f"ALLOWED_ORIGINSにCloudFrontのURLが含まれていません: {allowed_origins}"
                )

            if not distribution_ids:
                logger.warning("CloudFrontDistributionIDが見つかりませんでした")

            return distribution_ids

        except Exception as e:
            logger.error(f"CloudFrontDistributionID取得エラー: {str(e)}")
            return []

    def register_license(self, registration_code: str) -> Dict:
        """ライセンス登録

        Args:
            registration_code (str): 登録コード

        Returns:
            Dict: 登録結果

        Raises:
            ValueError: 登録に失敗した場合
        """
        try:
            if not self.license_server_url:
                raise ValueError("LICENSE_SERVER_API_URL環境変数が設定されていません")

            if not registration_code or not registration_code.strip():
                raise ValueError("登録コードが空です")

            # CloudFrontDistributionIDを自動取得
            cf_distribution_ids = self._get_cloudfront_distribution_ids()
            logger.debug(
                f"CloudFormationから取得したDistributionIDs: {cf_distribution_ids}"
            )

            # ライセンスサーバーへの登録リクエスト
            aws_context = self._get_aws_context()
            payload = {
                "registration-code": registration_code.strip(),
                "aws-account-id": aws_context["aws_account_id"],
                "cf-distribution-ids": cf_distribution_ids or [],
            }

            logger.info(f"ライセンス登録開始: Account={aws_context['aws_account_id']}")

            response = requests.post(
                f"{self.license_server_url}/license/register",
                json=payload,
                timeout=30,
                headers={"Content-Type": "application/json"},
            )

            if response.status_code == 200:
                result = response.json()
                logger.debug(f"ライセンス管理サーバーレスポンス: {result}")

                # ライセンス管理サーバのレスポンス内容を確認
                if result.get("status") == "error":
                    # HTTP 200だがエラーレスポンスの場合
                    error_message = result.get(
                        "message", "ライセンス登録に失敗しました"
                    )
                    logger.error(f"ライセンス管理サーバエラー: {error_message}")
                    raise ValueError(error_message)

                # 成功時の処理
                data = result.get("data", {})
                jwt_token = data.get("license_token")
                if jwt_token:
                    # レスポンスから公開鍵を取得
                    public_keys = data.get("public_keys")
                    if public_keys:
                        self._save_license_and_keys(jwt_token, public_keys)
                        logger.info("ライセンス登録完了、JWT+公開鍵をDynamoDBに保存")
                    else:
                        logger.warning(
                            "レスポンスに公開鍵が含まれていません、JWTのみ保存"
                        )
                        self._save_jwt_token(jwt_token)

                    # キャッシュレス設計により即座に有効
                    logger.info(
                        "[ライセンス登録] キャッシュレス設計により新しいライセンスが即座に有効になります"
                    )

                    # 成功メッセージをライセンス管理サーバから取得、またはデフォルト
                    success_message = result.get(
                        "message", "ライセンス登録が完了しました"
                    )
                    return {"success": True, "message": success_message, "data": result}
                else:
                    logger.warning(
                        f"ライセンス登録レスポンスにJWTトークンが含まれていません。利用可能キー: {list(result.keys())}"
                    )
                    # JWTトークンがない場合もエラーとして扱う
                    error_message = result.get(
                        "message",
                        "ライセンス登録は完了しましたが、認証情報の取得に失敗しました",
                    )
                    raise ValueError(error_message)
            else:
                error_message = f"ライセンス登録失敗: HTTP {response.status_code}"
                try:
                    error_data = response.json()
                    error_message += f" - {error_data.get('message', response.text)}"
                except:
                    error_message += f" - {response.text}"

                logger.error(error_message)
                raise ValueError(error_message)

        except requests.RequestException as e:
            error_message = f"ライセンスサーバー通信エラー: {str(e)}"
            logger.error(error_message)
            raise ValueError(error_message)
        except Exception as e:
            error_message = f"ライセンス登録エラー: {str(e)}"
            logger.error(error_message)
            raise ValueError(error_message)

    def get_license_status(self) -> Dict:
        """ライセンス状態取得

        DynamoDBからJWTトークンを取得し、ライセンス状態を返す

        Returns:
            Dict: ライセンス状態情報
        """
        try:
            # LicenseValidatorからJWTトークンを取得（重複削除）
            from utils.license_validator import license_validator

            jwt_token = license_validator._get_jwt_from_cache_or_db()

            if not jwt_token:
                # JWTがない場合は無料版
                return {
                    "plan": "free",
                    "status": "active",
                    "entitlements": self._get_free_version_entitlements(),
                    "message": "無料版をご利用中です",
                }

            # JWT検証（猶予期間を考慮）
            from .jwt_validator import JWTValidator

            jwt_validator = JWTValidator()
            payload = jwt_validator.validate_jwt_with_grace_period(jwt_token)

            if payload:
                # 有効なライセンス - JWTからライセンスコードを直接取得
                return {
                    "plan": payload.get("plan", "unknown"),
                    "status": payload.get("license-status", "active"),
                    "entitlements": payload.get("entitlements", {}),
                    "expiresAt": payload.get("exp"),
                    "gracePeriodMessage": payload.get("grace-period-message"),
                    "subject": payload.get("sub"),
                    "trial": payload.get("trial", False),
                    "isAutoRenew": True,  # Stripeサブスクリプション前提
                    "license-code": payload.get("license-code", "-"),  # JWTから直接取得
                    "current-period-end": payload.get(
                        "current-period-end"
                    ),  # 自動更新チェック用
                }
            else:
                # JWT無効または期限切れ
                logger.info("JWTが無効または猶予期間終了：無料版に移行")
                return {
                    "plan": "free",
                    "status": "expired-free",
                    "entitlements": self._get_free_version_entitlements(),
                    "message": "ライセンスが期限切れです。無料版制限が適用されています。",
                }

        except Exception as e:
            logger.error(f"ライセンス状態取得エラー: {str(e)}")
            # エラー時は無料版制限で継続
            return {
                "plan": "free",
                "status": "error",
                "entitlements": self._get_free_version_entitlements(),
                "message": "ライセンス状態の取得に失敗しました。無料版制限で動作します。",
            }

    # def refresh_license(self) -> Dict:
    #     """ライセンス更新処理 - REMOVED (未使用のため削除)
    #
    #     登録処理（register_license）で更新もまかなえるため、
    #     専用の更新処理は不要
    #     """

    def should_auto_refresh_license(self, license_info: Dict) -> bool:
        """
        自動更新が必要かを判定

        Args:
            license_info: 現在のライセンス情報

        Returns:
            bool: 自動更新が必要な場合True
        """
        try:
            # 無料版の場合は更新不要
            if license_info.get("plan") == "free":
                logger.debug("自動更新チェック: 無料版のため更新不要")
                return False

            # canceledライセンスは更新不要（一度キャンセルされたサブスクは再利用不可）
            status = license_info.get("status")
            if status == "canceled":
                logger.debug(
                    "自動更新チェック: canceledライセンスのため更新不要（ライセンス管理サーバ通信スキップ）"
                )
                return False

            # ライセンスコードが存在しない場合は更新不可
            license_code = license_info.get("license-code")
            if not license_code:
                logger.debug(
                    "自動更新チェック: ライセンスコードが見つからないため更新不可"
                )
                return False

            # 次回更新日をチェック
            current_period_end = license_info.get("current-period-end")
            if not current_period_end:
                logger.debug(
                    "自動更新チェック: 次回更新日が設定されていないため更新不要"
                )
                return False

            # 現在時刻と比較
            from datetime import datetime

            try:
                # ISO 8601形式の日付をパース
                if current_period_end.endswith("+09:00"):
                    end_date = datetime.fromisoformat(current_period_end)
                else:
                    # タイムゾーン情報がない場合はJSTとして扱う
                    end_date = datetime.fromisoformat(
                        current_period_end.replace("Z", "")
                    )
                    end_date = end_date.replace(tzinfo=timezone(timedelta(hours=9)))

                now = datetime.now(timezone(timedelta(hours=9)))  # JST
                is_expired = now > end_date

                logger.debug(
                    f"自動更新チェック: 現在時刻={now.isoformat()}, 次回更新日={end_date.isoformat()}, 期限切れ={is_expired}"
                )
                return is_expired

            except Exception as e:
                logger.warning(f"自動更新チェック: 日付解析エラー: {str(e)}")
                return False

        except Exception as e:
            logger.error(f"自動更新チェック: 予期せぬエラー: {str(e)}")
            return False

    def auto_refresh_license_if_needed(self, license_info: Dict) -> Dict:
        """
        必要に応じて自動更新を実行

        Args:
            license_info: 現在のライセンス情報

        Returns:
            Dict: 更新後のライセンス情報（更新不要または失敗時は元の情報）
        """
        try:
            # 自動更新が必要かチェック
            if not self.should_auto_refresh_license(license_info):
                return license_info

            # 登録されているライセンスコードを取得
            license_code = license_info.get("license-code")
            if not license_code:
                logger.warning("自動更新: ライセンスコードが見つかりません")
                return license_info

            logger.info(f"自動更新開始: ライセンスコード={license_code[:8]}...")

            # 既存の登録処理を使用して更新
            result = self.register_license(license_code)

            if result.get("success"):
                logger.info(f"自動更新完了: ライセンスコード={license_code[:8]}...")
                return result.get("data", license_info)
            else:
                error_message = result.get("message", "不明なエラー")
                logger.warning(f"自動更新失敗: {error_message}")
                return license_info

        except ValueError as e:
            error_message = str(e)
            logger.error(f"自動更新エラー: {error_message}")
            return license_info  # その他のエラー時は既存情報を返す
        except Exception as e:
            logger.error(f"自動更新エラー: {str(e)}")
            return license_info  # 失敗時は既存情報を返す

    def switch_to_free(self) -> Dict:
        """無料版切り替え

        DynamoDBからライセンストークンを削除し、無料版に切り替え

        Returns:
            Dict: 切り替え結果
        """
        try:
            # DynamoDBからライセンストークンを削除
            self.manage_table.delete_item(
                Key={"id": "license-token", "type": "license"}
            )

            logger.info("ライセンストークン削除完了：無料版に切り替え")

            return {"success": True, "message": "無料版に切り替えました"}
        except Exception as e:
            logger.error(f"無料版切り替えエラー: {str(e)}")
            raise ValueError(f"無料版への切り替えに失敗しました: {str(e)}")

    def _save_jwt_token(self, jwt_token: str) -> None:
        """JWTトークンをDynamoDBに保存

        Args:
            jwt_token (str): 保存するJWTトークン
        """
        try:
            self.manage_table.put_item(
                Item={
                    "id": "license-token",
                    "type": "license",
                    "license_token": jwt_token,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                    "created_by": "license-service",
                }
            )
            logger.info("JWTトークンをDynamoDBに保存完了")
        except Exception as e:
            logger.error(f"JWTトークン保存エラー: {str(e)}")
            raise

    def _get_jwt_from_db(self) -> Optional[str]:
        """DynamoDBからJWTトークンを取得（リトライ付き）

        Returns:
            Optional[str]: JWTトークン、見つからない場合はNone
        """
        max_retries = 3
        base_delay = 5

        for attempt in range(max_retries):
            try:
                response = self.manage_table.get_item(
                    Key={"id": "license-token", "type": "license"}
                )

                if "Item" in response:
                    jwt_token = response["Item"].get("license_token")
                    if jwt_token:
                        logger.debug("JWTトークン取得成功")
                        return jwt_token
                    else:
                        logger.warning("JWTトークンが空です")
                        return None
                else:
                    logger.info("ライセンストークンが見つかりません")
                    return None

            except Exception as e:
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)  # 指数関数的増加
                    logger.warning(
                        f"DynamoDB接続失敗（{attempt + 1}/{max_retries}）: {delay}秒後にリトライ - {str(e)}"
                    )
                    time.sleep(delay)
                else:
                    logger.error(f"DynamoDB接続失敗（全{max_retries}回）: {str(e)}")
                    raise

        return None

    def _get_free_version_entitlements(self) -> Dict:
        """無料版の制限値を取得

        Returns:
            Dict: 無料版の制限値
        """
        return {
            "max-projects": 1,
            "max-categories-per-project": 3,
            "max-common-categories": 3,
            "max-rag-settings": 1,
            "max-review-perspectives": 3,
        }

    def get_aws_context(self) -> Dict[str, str]:
        """AWS実行コンテキストを取得

        Returns:
            Dict[str, str]: AWS Account IDとRegion
        """
        return self._get_aws_context()

    # 外部公開鍵取得メソッドを削除しました（不要な外部API呼び出しを排除）
    # 公開鍵はライセンス登録・更新レスポンスから直接取得します

    def _save_license_and_keys(self, jwt_token: str, public_keys: Dict) -> None:
        """JWTトークンと公開鍵を暗号化してDynamoDBに保存

        Args:
            jwt_token (str): 保存するJWTトークン
            public_keys (Dict): 保存する公開鍵情報
        """
        try:
            # データ暗号化ユーティリティをインポート
            from utils.data_utils import encode_data

            # JWTトークンと公開鍵を暗号化
            encrypted_jwt = encode_data(jwt_token)
            encrypted_keys = encode_data(json.dumps(public_keys))

            self.manage_table.put_item(
                Item={
                    "id": "license-token",
                    "type": "license",
                    "license_token": encrypted_jwt,
                    "public_keys": encrypted_keys,
                    "keys_updated_at": datetime.now(timezone.utc).isoformat(),
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                    "created_by": "license-service",
                }
            )
            logger.info("暗号化されたJWT+公開鍵をDynamoDBに保存完了")
        except Exception as e:
            logger.error(f"暗号化JWT+公開鍵保存エラー: {str(e)}")
            raise

    def _get_license_record_from_db(self) -> Optional[Dict]:
        """DynamoDBからライセンスレコードを取得（ライセンスコード取得用）"""
        try:
            import boto3
            from botocore.exceptions import ClientError

            # JWTからテナントIDを取得（より正確）
            jwt_token = self._get_jwt_from_db()
            if not jwt_token:
                logger.warning(
                    "JWTトークンが見つからないため、ライセンスコードを取得できません"
                )
                return None

            # JWTをデコードしてsubject（テナントID）を取得
            import jwt

            try:
                # 署名検証なしでペイロードだけ取得（subjectのみ必要）
                payload = jwt.decode(jwt_token, options={"verify_signature": False})
                customer_id = payload.get("sub")  # cus_T0jecG3rV9ZZRA
                tenant_id = f"tenant-{customer_id}"
                logger.debug(f"JWTからテナントID取得: {tenant_id}")
            except Exception as e:
                logger.error(f"JWT解析エラー: {str(e)}")
                return None

            dynamodb = boto3.client("dynamodb", region_name="ap-northeast-1")

            # ライセンス管理サーバのテーブルから取得
            license_table_name = (
                "reviewmaster-license-server-dev-license-management-table"
            )

            response = dynamodb.get_item(
                TableName=license_table_name,
                Key={"tenant-id": {"S": tenant_id}, "record-type": {"S": "LICENSE"}},
            )

            if "Item" in response:
                # DynamoDB形式から通常の辞書に変換
                item = {}
                for key, value in response["Item"].items():
                    if "S" in value:
                        item[key] = value["S"]
                    elif "N" in value:
                        item[key] = value["N"]
                    elif "B" in value:
                        item[key] = value["B"]
                return item
            else:
                logger.warning(f"ライセンスレコードが見つかりません: {tenant_id}")
                return None

        except Exception as e:
            logger.error(f"ライセンスレコード取得エラー: {str(e)}")
            return None

    def _get_plan_display_name(self, plan: str) -> str:
        """
        プラン名を表示用に変換

        Args:
            plan: プランID

        Returns:
            str: 表示用プラン名
        """
        plan_names = {
            "pro": "Pro版",
            "basic": "Basic版",
            "enterprise": "Enterprise版",
            "free": "無料版",
        }
        return plan_names.get(plan, plan)
