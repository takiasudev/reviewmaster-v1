#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
config_manager用ライセンス制限値定義

共通制限値の個別コピーバージョン
Pyarmorでの難読化対象として各Lambda関数に配置
"""

import logging

logger = logging.getLogger(__name__)

class LicenseLimits:
    """フォールバック用の無料版制限値定義"""
    
    # 無料版制限値（JWT取得失敗時のフォールバック）
    FREE_LIMITS = {
        "max-projects": 1,
        "max-categories-per-project": 3,
        "max-common-categories": 3,
        "max-rag-settings": 1,
        "max-review-perspectives": 3
    }
    
    @classmethod
    def get_free_limits(cls) -> dict:
        """無料版制限値取得（フォールバック用）
        
        Returns:
            dict: 無料版制限値のコピー
        """
        limits = cls.FREE_LIMITS.copy()
        logger.info(f"[config_manager] フォールバック制限値を取得: {limits}")
        return limits
